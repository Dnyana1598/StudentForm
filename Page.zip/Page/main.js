document.getElementById("admissionForm").addEventListener("submit", function(event){
    event.preventDefault();
    alert("Form submitted sucessfully!!")
})